%EE569 HOMEWORK ASSIGNMENT 2
%DATE: Feb 23th 2021
%NAME: Siyu Li
%ID:2455870216
%E-mail:lisiyu@usc.edu
function []=hw2problem1c()
edgesDemo;
% adjust the detection parameters by hand to get all the images in my
% report, here I only used the optimal value.
end