% close all, clc
%
% USAGE
%  cc
%
% INPUTS
%
% OUTPUTS
%
% EXAMPLE
%
% See also C, CCC
%
% Piotr's Computer Vision Matlab Toolbox      Version 1.5
% Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
% Licensed under the Simplified BSD License [see external/bsd.txt]

close all; clc
