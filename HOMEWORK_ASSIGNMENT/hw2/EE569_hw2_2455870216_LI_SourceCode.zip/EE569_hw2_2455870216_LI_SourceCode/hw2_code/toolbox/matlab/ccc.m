% clear, close all, clc, clear global
%
% USAGE
%  ccc
%
% INPUTS
%
% OUTPUTS
%
% EXAMPLE
%
% See also C, CC
%
% Piotr's Computer Vision Matlab Toolbox      Version 1.5
% Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
% Licensed under the Simplified BSD License [see external/bsd.txt]

clear; close all; clc; clear all;
