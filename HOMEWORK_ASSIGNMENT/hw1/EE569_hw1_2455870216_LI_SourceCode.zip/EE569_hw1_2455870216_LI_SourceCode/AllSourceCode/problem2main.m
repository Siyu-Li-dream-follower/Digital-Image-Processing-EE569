%EE569 HOMEWORK ASSIGNMENT 1
%DATE: Feb 7th 2021
%NAME: Siyu Li
%ID:2455870216
%E-mail:lisiyu@usc.edu

% Before running the code. Open all problem##.m such as problem21.m files first to change the root of the raw file in order to read raw file successfully and write them into
% proper position. (In function ModifiedReadraw and universalwriteraw) !!!

% Due to the high computational complexity of NL Means method, I deliberately set the loop for searching parameter so only optimal value parameter
% set is traversed here to save the time of grader's. If you want to run more to compare with the result in my report you can add value to the array 
% of the loop in problem23.m and problem24.m. Other parameters for NL Means filter I have used are just behind the loop in the notation part. 
% You can just add it and run the code again.

% In this homework I wrote all the functions myself so there will not be any open source code in problem2 NL Means related parts.

%%%Problem 2 main function

disp('problem 2-1, enter to continue')
pause
problem21
disp('problem 2-2, enter to continue')
pause
problem22
disp('problem 2-3, enter to continue')
pause
problem23
disp('problem 2-4, enter to continue')
pause
problem24
