%EE569 HOMEWORK ASSIGNMENT 1
%DATE: Feb 7th 2021
%NAME: Siyu Li
%ID:2455870216
%E-mail:lisiyu@usc.edu
%%%Problem 1 main function

% Before running the code. Open all problem##.m such as problem21.m files first to change the root of the raw file in order to read raw file successfully and write them into
% proper position. (In function ModifiedReadraw and universalwriteraw) !!!

disp('problem 1-1, enter to continue')
pause
problem11
disp('problem 1-2, enter to continue')
pause
problem12
disp('problem 1-3, enter to continue')
pause
problem13
disp('problem 1-4, enter to continue')
pause
problem14