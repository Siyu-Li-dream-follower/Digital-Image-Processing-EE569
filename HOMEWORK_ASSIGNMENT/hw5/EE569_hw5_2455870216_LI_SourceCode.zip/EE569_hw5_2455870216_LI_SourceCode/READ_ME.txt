# EE569 HOMEWORK ASSIGNMENT 5
# DATE: Aprile 14th 2021
# NAME: Siyu Li
# ID:2455870216
# E-mail:lisiyu@usc.edu

1. Install all the relevant environment like tensorflow, keras etc if you have not done so.

2. All the codes are programmed under the framwork of tensorflow.

3. All the ipynb files named EE569HW5Problem1xxx are executive files. 

4. Before runing those executive files, change the parameters based on your need. If you want to use my optimal parameters,

   it is just in the notation at first or it has already been in the code.

5. You can see both the exact precise data in each epoch in iteration and the overall performance curve in the result at the end. 
