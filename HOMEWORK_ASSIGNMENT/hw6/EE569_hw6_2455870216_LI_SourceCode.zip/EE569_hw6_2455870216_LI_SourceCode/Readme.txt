# EE569 HOMEWORK ASSIGNMENT 6
# DATE: Aprile 30th 2021
# NAME: Siyu Li
# ID:2455870216
# E-mail:lisiyu@usc.edu

##############################################################
1. Install all the libraries that are imported.

2. The executive files are xxx.ipynb. The output results were saved and you can see them directly if you do not want do run the code again.

3. Problem 2 (b) is in the xxx.ipynb with saab in the filename.

4. Problem 2 (a) 3) is in xxx.ipynb with TH1 in the filename.

5. Problem 2 (a) rest and Problem 2 (c) is in xxx.ipynb with cwsaab and woithout TH1 in the filename.
