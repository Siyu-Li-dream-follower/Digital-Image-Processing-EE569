%EE569 HOMEWORK ASSIGNMENT 3
%DATE: Mar 12th 2021
%NAME: Siyu Li
%ID:2455870216
%E-mail:lisiyu@usc.edu
Attention: Read all the things below before running the code, thanks!

1. All the raw image filepath has been replaced by its name namely the relative filepath. Full file path may be needed to run the code successfully.

2. Run all the m function hw3problem### to get the result, these are main executive functions. 

3. I have hw3writeraw and saveas to save result pictures in my report but for convenience I also have imshow in my code for you to review the result
so I have notation on all hw3writeraw and saveas sentence in my code. If you want to save the file ,you can just remove the notation on it and adjust the
corresponding filepath to save image to your computer.


############################################
Explanation of some of the functions:
The workload of this homework is hugh so I make the m function name as self-evident as possible to make you understand what they are used for.
Sorry that I do not have time to explain the m functions.